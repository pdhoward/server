'use strict';

const mongoose = require("mongoose");
const uuidv1 =  require('uuid/v1')

const agentSchema = mongoose.Schema({
    agentname: {
      type: String,
      unique: true,
      required: true
    },
    avatar: String,
    greeting: String,
    priority: { type: Number, default: 1 },
    skills: [ {
      skillname: String,
      skillsource: String }
    ],
    handle: String,
    handler: String,
    postdate: { type: Date, default: Date.now },
    id: { type: String, default: uuidv1() }
})

module.exports = mongoose.model('Agent', agentSchema);


//////////////////////////////////////////////////////////////////////////
////////////////////    Uniform Response Schema     /////////////////////
////////////////////////////////////////////////////////////////////////

const mongoose = require("mongoose");
const uuidv1 =  require('uuid/v1')
const Schema = mongoose.Schema;

// refactor for required fields and validation routines
// for example, chaoticsource on the message object points to channel
// sms, web, fb, telegram, twitter ....
const interactObject = {
  message: {
    MessageSid: String,
    SmsSid: String,
    AccountSid: String,
    MessagingServiceSid: String,
    From: String,
    To: String,
    Body: String,
    NumMedia: String,
    NumSegments: String,
    MediaContentType: String,
    MediaUrl: String,
    FromCity: String,
    FromState: String,
    FromZip: String,
    FromCounty: String,
    SmsStatus: String,
    ToCity: String,
    ToState: String,
    ToZip: String,
    ToCountry: String,
    AddOns: String,
    ApiVersion: String,
    PostDate: { type: Date, default: Date.now },
    ChaoticSid: { type: String, default: uuidv1 },
    ChaoticSource: String
  },
  machine: {
    name: String,
    state: String,
    iterations: Number,
    msg: String,
    isValid: { type: Boolean, default: true }
  },
  agent: {
    name: String,
    skill: String,
    skillsource: String,
    avatar: String,
    greeting: String,
    priority: Number,
    iterations: { type: Number, default: 1 },
    isValid: { type: Boolean, default: true }
  },
  route: Object,
  classifier: Object,
  response: Object,
  intent: {
    agent: String,
    isCallback: { type: Boolean, default: false },
    isTerminated: { type: Boolean, default: false },
    isError: { type: Boolean, default: false },
    isErrorMsg: Object,
    response: {
     sender: String,
     orgmessage: Object,
     reply: Array,
     confidence: Number,
     percent: String
      }
    },
  system: {
    meter: Object,
    msg: String
    },
  org: String,
  PostDate: { type: Date, default: Date.now },
  id: { type: String, default: uuidv1() }
}

const interactSchema = new Schema(interactObject, {collection: Interact});

var Interact = mongoose.model("Interact", interactSchema);

module.exports = { Interact, interactObject }

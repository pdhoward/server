
//////////////////////////////////////////////////////////////////////////
////////////////////    Uniform Response Schema     /////////////////////
////////////////////////////////////////////////////////////////////////

const mongoose = require("mongoose");
const uuidv1 =  require('uuid/v1')
const Schema = mongoose.Schema;

const responseObject = {
  org: String,
  rowid: String,
  responseid: String,
  effectivedate: String,
  effectivetime: String,
  expiredate: String,
  expiretime: String,
  skill: String,
  responses: String,
  redirecturl: String,
  mediaurl: String,
  attachurl: String,
  isMedia: Boolean,
  isAttach: Boolean,
  isRedirect: Boolean,
  PostDate: { type: Date, default: Date.now },
  ChaoticSid: { type: String, default: uuidv1() }
}

const responseSchema = new Schema(responseObject);

var Response = mongoose.model("Response", responseSchema);

module.exports = { Response, responseObject }
